<?php
require_once 'configuracao/config.php';
require_once 'classes/Venda.php';

require_login();

$conn = db_connect();
$sale_obj = new Sale($conn);

$id = $_GET['id'] ?? 0;
$sale = $sale_obj->getById($id);

if (!$sale) {
    display_error('Venda não encontrada.');
    redirect(BASE_URL . 'vendas.php');
}

$html = '<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota Fiscal - Venda #' . $sale['id'] . '</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: Arial, sans-serif; 
            padding: 30px;
            background: white;
            color: #333;
            line-height: 1.6;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #3b82f6;
        }
        .company-name {
            font-size: 32px;
            font-weight: bold;
            color: #3b82f6;
            margin-bottom: 5px;
        }
        .document-title {
            font-size: 24px;
            color: #1e40af;
            margin-top: 15px;
        }
        .info-section {
            margin: 25px 0;
            padding: 15px;
            background: #f9fafb;
            border-left: 4px solid #3b82f6;
            border-radius: 4px;
        }
        .info-row {
            display: flex;
            margin: 8px 0;
        }
        .info-label {
            font-weight: bold;
            min-width: 180px;
            color: #1e40af;
        }
        .info-value {
            color: #4b5563;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin: 25px 0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        th { 
            background-color: #3b82f6; 
            color: white; 
            padding: 14px 12px; 
            text-align: left;
            font-weight: bold;
            font-size: 14px;
        }
        td { 
            padding: 12px; 
            border-bottom: 1px solid #e5e7eb;
        }
        tr:nth-child(even) {
            background-color: #f9fafb;
        }
        .total-row {
            background-color: #dbeafe !important;
            font-weight: bold;
            font-size: 16px;
        }
        .total-label {
            text-align: right;
            padding-right: 20px;
            color: #1e40af;
        }
        .total-value {
            color: #3b82f6;
            font-size: 18px;
        }
        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 2px solid #e5e7eb;
            text-align: center;
            color: #6b7280;
            font-size: 12px;
        }
        .notes {
            margin: 20px 0;
            padding: 15px;
            background: #fef3c7;
            border-left: 4px solid #f59e0b;
            border-radius: 4px;
        }
        .notes-title {
            font-weight: bold;
            color: #92400e;
            margin-bottom: 8px;
        }
        .print-button {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #3b82f6;
            color: white;
            border: none;
            padding: 14px 28px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
            transition: all 0.3s;
            z-index: 1000;
        }
        .print-button:hover {
            background: #2563eb;
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(59, 130, 246, 0.4);
        }
        .back-button {
            position: fixed;
            top: 20px;
            right: 160px;
            background: #6b7280;
            color: white;
            border: none;
            padding: 14px 28px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            box-shadow: 0 4px 12px rgba(107, 114, 128, 0.3);
            transition: all 0.3s;
            z-index: 1000;
        }
        .back-button:hover {
            background: #4b5563;
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(107, 114, 128, 0.4);
        }
        @media print {
            .print-button, .back-button { display: none; }
            body { padding: 0; }
        }
        @page {
            size: A4;
            margin: 1.5cm;
        }
    </style>
</head>
<body>
    <a href="vendas.php" class="back-button">← Voltar</a>
    <button onclick="window.print()" class="print-button">🖨 Imprimir</button>
    
    <div class="header">
        <div class="company-name">Diamond System</div>
        <div class="document-title">NOTA FISCAL DE VENDA</div>
    </div>
    
    <div class="info-section">
        <div class="info-row">
            <span class="info-label">Número da Nota:</span>
            <span class="info-value">#' . str_pad($sale['id'], 6, '0', STR_PAD_LEFT) . '</span>
        </div>
        <div class="info-row">
            <span class="info-label">Data de Emissão:</span>
            <span class="info-value">' . format_date($sale['sale_date']) . '</span>
        </div>
        <div class="info-row">
            <span class="info-label">Status:</span>
            <span class="info-value">' . ucfirst($sale['status']) . '</span>
        </div>
    </div>
    
    <div class="info-section">
        <h3 style="color: #1e40af; margin-bottom: 12px;">Dados do Cliente</h3>
        <div class="info-row">
            <span class="info-label">Nome:</span>
            <span class="info-value">' . htmlspecialchars($sale['client_name'] ?: 'Não registrado') . '</span>
        </div>
        ' . ($sale['client_cpf'] ? '<div class="info-row">
            <span class="info-label">CPF:</span>
            <span class="info-value">' . formatar_cpf($sale['client_cpf']) . '</span>
        </div>' : '') . '
        ' . ($sale['client_email'] ? '<div class="info-row">
            <span class="info-label">Email:</span>
            <span class="info-value">' . htmlspecialchars($sale['client_email']) . '</span>
        </div>' : '') . '
        ' . ($sale['client_phone'] ? '<div class="info-row">
            <span class="info-label">Telefone:</span>
            <span class="info-value">' . formatar_telefone($sale['client_phone']) . '</span>
        </div>' : '') . '
    </div>
    
    <div class="info-section">
        <h3 style="color: #1e40af; margin-bottom: 12px;">Dados do Vendedor</h3>
        <div class="info-row">
            <span class="info-label">Vendedor:</span>
            <span class="info-value">' . htmlspecialchars($sale['user_name']) . '</span>
        </div>
        <div class="info-row">
            <span class="info-label">Forma de Pagamento:</span>
            <span class="info-value">' . htmlspecialchars($sale['payment_method']) . '</span>
        </div>
    </div>
    
    <h3 style="color: #1e40af; margin: 30px 0 15px 0;">Itens da Venda</h3>
    <table>
        <thead>
            <tr>
                <th style="width: 50%;">Produto</th>
                <th style="width: 15%; text-align: center;">Quantidade</th>
                <th style="width: 17.5%; text-align: right;">Preço Unit.</th>
                <th style="width: 17.5%; text-align: right;">Subtotal</th>
            </tr>
        </thead>
        <tbody>';

foreach ($sale['items'] as $item) {
    $html .= '
            <tr>
                <td>' . htmlspecialchars($item['product_name']) . '</td>
                <td style="text-align: center;">' . $item['quantity'] . '</td>
                <td style="text-align: right;">' . format_money($item['price']) . '</td>
                <td style="text-align: right;">' . format_money($item['subtotal']) . '</td>
            </tr>';
}

$html .= '
            <tr class="total-row">
                <td colspan="3" class="total-label">VALOR TOTAL:</td>
                <td class="total-value" style="text-align: right;">' . format_money($sale['total']) . '</td>
            </tr>
        </tbody>
    </table>';

if ($sale['notes']) {
    $html .= '
    <div class="notes">
        <div class="notes-title">Observações:</div>
        <div>' . nl2br(htmlspecialchars($sale['notes'])) . '</div>
    </div>';
}

$html .= '
    
    <div class="footer">
        <p>Este documento é uma nota fiscal simplificada.</p>
        <p>Emitido por Diamond System em ' . date('d/m/Y H:i:s') . '</p>
        <p>Obrigado pela preferência!</p>
    </div>
    
    <script>
        // Descomente a linha abaixo para imprimir automaticamente ao abrir
        // window.onload = function() { window.print(); };
    </script>
</body>
</html>';

echo $html;
db_close($conn);
exit;
?>
