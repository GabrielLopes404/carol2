<?php
require_once 'configuracao/config.php';
require_once 'classes/Usuario.php';

require_login();

if (!isset($_SESSION['first_login']) || $_SESSION['first_login'] != 1) {
    redirect(BASE_URL . 'painel.php');
}

$conn = db_connect();
$user = new User($conn);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $current_user = $user->getById($_SESSION['user_id']);
    
    if (!password_verify($current_password, $current_user['password'])) {
        $error = 'Senha atual incorreta.';
    } elseif (strlen($new_password) < 6) {
        $error = 'A nova senha deve ter no mínimo 6 caracteres.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'As senhas não coincidem.';
    } else {
        if ($user->updatePassword($_SESSION['user_id'], $new_password)) {
            $_SESSION['first_login'] = 0;
            display_success('Senha alterada com sucesso!');
            redirect(BASE_URL . 'painel.php');
        } else {
            $error = 'Erro ao alterar senha.';
        }
    }
}

$page_title = 'Alterar Senha';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Diamond System</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="<?php echo BASE_URL; ?>recursos/css/estilo.css" rel="stylesheet">
    
    <style>
        html {
            overflow-y: auto;
            scroll-behavior: smooth;
        }
        
        body {
            overflow-y: auto;
        }
        
        .password-change-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            padding: 20px;
        }
        
        .password-bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(120px);
            opacity: 0.3;
            animation: float 20s ease-in-out infinite;
        }
        
        .shape-1 {
            width: 600px;
            height: 600px;
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            top: -200px;
            right: -200px;
        }
        
        .shape-2 {
            width: 400px;
            height: 400px;
            background: linear-gradient(135deg, #3b82f6, #06b6d4);
            bottom: -100px;
            left: -100px;
        }
        
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(50px, -50px) scale(1.1); }
            50% { transform: translate(-30px, 30px) scale(0.9); }
            75% { transform: translate(40px, 40px) scale(1.05); }
        }
        
        .password-card {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 480px;
            background: rgba(10, 15, 26, 0.95) !important;
            backdrop-filter: blur(40px) saturate(180%);
            border: 1px solid rgba(139, 92, 246, 0.3) !important;
            border-radius: 18px !important;
            box-shadow: 0 20px 80px rgba(0, 0, 0, 0.5), 0 0 60px rgba(139, 92, 246, 0.2) !important;
            overflow: hidden;
            animation: slideUp 0.6s cubic-bezier(0.4, 0, 0.2, 1);
            margin: auto;
        }
        
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .password-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #8b5cf6, #ec4899, transparent);
            animation: shimmerTop 3s linear infinite;
        }
        
        @keyframes shimmerTop {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        .password-header {
            text-align: center;
            padding: 20px 20px 16px;
            background: linear-gradient(180deg, rgba(139, 92, 246, 0.1), transparent);
            border-bottom: 1px solid rgba(139, 92, 246, 0.15);
        }
        
        .password-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            border-radius: 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            margin-bottom: 12px;
            animation: pulse-icon 3s ease-in-out infinite;
            position: relative;
        }
        
        .password-icon::before {
            content: '';
            position: absolute;
            inset: -3px;
            border-radius: 22px;
            padding: 3px;
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.6), rgba(236, 72, 153, 0.6));
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            animation: rotate-border 4s linear infinite;
        }
        
        @keyframes pulse-icon {
            0%, 100% { box-shadow: 0 0 0 0 rgba(139, 92, 246, 0.7); }
            50% { box-shadow: 0 0 0 25px rgba(139, 92, 246, 0); }
        }
        
        @keyframes rotate-border {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .password-title {
            font-size: 20px;
            font-weight: 900;
            background: linear-gradient(135deg, #a78bfa, #f0abfc);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 4px;
        }
        
        .password-subtitle {
            color: var(--muted-text);
            font-size: 12px;
            line-height: 1.3;
        }
        
        .password-body {
            padding: 20px 24px 24px 24px;
        }
        
        .password-input-group {
            position: relative;
            margin-bottom: 14px;
        }
        
        .password-label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--white-text) !important;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .password-input-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }
        
        .password-input-icon {
            position: absolute;
            left: 18px;
            color: #a78bfa;
            font-size: 18px;
            z-index: 2;
            pointer-events: none;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .password-input {
            width: 100%;
            padding: 11px 16px 11px 44px !important;
            background: rgba(139, 92, 246, 0.06) !important;
            border: 2px solid rgba(139, 92, 246, 0.25) !important;
            border-radius: 10px !important;
            color: var(--white-text) !important;
            font-size: 13px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .password-input:focus {
            background: rgba(139, 92, 246, 0.1) !important;
            border-color: #8b5cf6 !important;
            box-shadow: 0 0 0 4px rgba(139, 92, 246, 0.2) !important;
            transform: translateY(-2px);
            outline: none;
        }
        
        .password-hint {
            display: block;
            font-size: 12px;
            color: var(--muted-text);
            margin-top: 6px;
            padding-left: 4px;
        }
        
        .password-btn {
            width: 100%;
            padding: 11px !important;
            background: linear-gradient(135deg, #8b5cf6, #ec4899) !important;
            border: none !important;
            border-radius: 10px !important;
            color: white !important;
            font-size: 13px !important;
            font-weight: 700 !important;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            margin-top: 6px;
        }
        
        .password-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 40px rgba(139, 92, 246, 0.4);
        }
        
        .password-btn:active {
            transform: translateY(-1px);
        }
        
        .alert-danger {
            background: rgba(239, 68, 68, 0.15) !important;
            border: 1px solid rgba(239, 68, 68, 0.3) !important;
            color: #fca5a5 !important;
            border-radius: 10px !important;
            padding: 10px 12px;
            margin-bottom: 14px;
            font-size: 12px;
        }
        
        .security-note {
            background: rgba(59, 130, 246, 0.08);
            border: 1px solid rgba(59, 130, 246, 0.2);
            border-radius: 10px;
            padding: 10px;
            margin-top: 12px;
            display: flex;
            align-items: start;
            gap: 8px;
        }
        
        .security-note-icon {
            color: #60a5fa;
            font-size: 16px;
            margin-top: 1px;
        }
        
        .security-note-text {
            font-size: 11px;
            color: var(--muted-text);
            line-height: 1.5;
        }
    </style>
</head>
<body>
    <div class="password-change-container">
        <div class="password-bg-shape shape-1"></div>
        <div class="password-bg-shape shape-2"></div>
        
        <div class="password-card">
            <div class="password-header">
                <div class="password-icon">
                    <i class="fas fa-shield-halved"></i>
                </div>
                <h1 class="password-title">Alterar Senha</h1>
                <p class="password-subtitle">Por segurança, altere sua senha no primeiro acesso<br>para proteger sua conta</p>
            </div>
            
            <div class="password-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <form method="post">
                    <div class="password-input-group">
                        <label for="current_password" class="password-label">Senha Atual</label>
                        <div class="password-input-wrapper">
                            <i class="fas fa-lock password-input-icon"></i>
                            <input type="password" class="password-input" id="current_password" name="current_password" placeholder="Digite sua senha atual" required autofocus>
                        </div>
                    </div>
                    
                    <div class="password-input-group">
                        <label for="new_password" class="password-label">Nova Senha</label>
                        <div class="password-input-wrapper">
                            <i class="fas fa-key password-input-icon"></i>
                            <input type="password" class="password-input" id="new_password" name="new_password" placeholder="Digite sua nova senha" required>
                        </div>
                        <span class="password-hint"><i class="fas fa-info-circle me-1"></i>Mínimo de 6 caracteres</span>
                    </div>
                    
                    <div class="password-input-group">
                        <label for="confirm_password" class="password-label">Confirmar Nova Senha</label>
                        <div class="password-input-wrapper">
                            <i class="fas fa-check-circle password-input-icon"></i>
                            <input type="password" class="password-input" id="confirm_password" name="confirm_password" placeholder="Confirme sua nova senha" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="password-btn">
                        <span style="position: relative; z-index: 1;">
                            <i class="fas fa-shield-check me-2"></i>Confirmar Alteração
                        </span>
                    </button>
                    
                    <div class="security-note">
                        <i class="fas fa-lightbulb security-note-icon"></i>
                        <div class="security-note-text">
                            <strong>Dica de Segurança:</strong> Use uma senha forte com letras maiúsculas, minúsculas, números e caracteres especiais. Nunca compartilhe sua senha com terceiros.
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
db_close($conn);
?>
