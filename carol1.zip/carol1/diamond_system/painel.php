<?php
require_once 'configuracao/config.php';
require_once 'classes/Produto.php';
require_once 'classes/Venda.php';

require_login();

$conn = db_connect();

$stats = get_dashboard_stats($conn);
$chart_data = get_chart_data($conn);

$product = new Product($conn);
$sale = new Sale($conn);

$low_stock_products = $product->getLowStock(10);
$recent_sales = $sale->getRecentSales(10);

$page_title = 'Dashboard';

require_once 'inclusoes/cabecalho.php';
require_once 'inclusoes/menu_lateral.php';
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-chart-line me-2"></i>Dashboard</h1>
    <div class="btn-toolbar mb-2 d-flex align-items-center gap-2">
        <div class="user-badge">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
        </div>
        <div class="role-badge role-<?php echo $_SESSION['user_role']; ?>">
            <i class="fas fa-shield-alt"></i>
            <span><?php echo ucfirst($_SESSION['user_role'] == 'admin' ? 'Administrador' : ($_SESSION['user_role'] == 'manager' ? 'Gerente' : 'Vendedor')); ?></span>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card card-dashboard">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="stat-icon-blue p-3 rounded-3 me-3">
                        <i class="fas fa-dollar-sign fa-2x"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 small">Vendas Hoje</p>
                        <h4 class="mb-0"><?php echo format_money($stats['sales_today']); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card card-dashboard">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="stat-icon-emerald p-3 rounded-3 me-3">
                        <i class="fas fa-calendar-alt fa-2x"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 small">Vendas do Mês</p>
                        <h4 class="mb-0"><?php echo format_money($stats['sales_month']); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card card-dashboard">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="stat-icon-cyan p-3 rounded-3 me-3">
                        <i class="fas fa-users fa-2x"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 small">Total de Clientes</p>
                        <h4 class="mb-0"><?php echo $stats['total_clients']; ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card card-dashboard">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="stat-icon-yellow p-3 rounded-3 me-3">
                        <i class="fas fa-exclamation-triangle fa-2x"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 small">Estoque Baixo</p>
                        <h4 class="mb-0"><?php echo $stats['low_stock']; ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xl-8">
        <div class="card" style="background-color:#0b0f1a;">
            <div class="card-header border-0" style="background-color:#0b0f1a;">
                <h5 class="card-title mb-0 text-light"><i class="fas fa-wave-square me-2 text-primary"></i>Vendas dos Últimos 7 Dias</h5>
            </div>
            <div class="card-body">
                <canvas id="salesChart" style="height: 300px;"></canvas>
            </div>
        </div>
    </div>
    
    <div class="col-xl-4">
        <div class="card" style="background-color:#0b0f1a;">
            <div class="card-header border-0" style="background-color:#0b0f1a;">
                <h5 class="card-title mb-0 text-light"><i class="fas fa-chart-pie me-2 text-info"></i>Vendas por Categoria</h5>
            </div>
            <div class="card-body">
                <canvas id="categoryChart" style="height: 300px;"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="fas fa-exclamation-circle me-2"></i>Produtos com Estoque Baixo</h5>
            </div>
            <div class="card-body">
                <?php if (empty($low_stock_products)): ?>
                    <p class="text-muted text-center py-3">Nenhum produto com estoque baixo.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Produto</th>
                                    <th>Categoria</th>
                                    <th>Estoque</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($low_stock_products as $p): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($p['name']); ?></td>
                                    <td><?php echo htmlspecialchars($p['category_name'] ?? 'N/A'); ?></td>
                                    <td><span class="badge bg-warning"><?php echo $p['stock']; ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="fas fa-shopping-cart me-2"></i>Vendas Recentes</h5>
            </div>
            <div class="card-body">
                <?php if (empty($recent_sales)): ?>
                    <p class="text-muted text-center py-3">Nenhuma venda registrada.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th style="width: 10%;">#</th>
                                    <th style="width: 30%;">Cliente</th>
                                    <th style="width: 25%;">Vendedor</th>
                                    <th style="width: 20%;">Total</th>
                                    <th style="width: 15%;">Data</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_sales as $s): ?>
                                <tr>
                                    <td><span class="badge bg-primary">#<?php echo $s['id']; ?></span></td>
                                    <td><?php echo htmlspecialchars($s['client_name'] ?: 'N/A'); ?></td>
                                    <td>
                                        <span class="badge bg-info">
                                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($s['user_name'] ?: 'N/A'); ?>
                                        </span>
                                    </td>
                                    <td><strong><?php echo format_money($s['total']); ?></strong></td>
                                    <td><?php echo date('d/m H:i', strtotime($s['sale_date'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const salesData = <?php echo json_encode($chart_data['sales_week']); ?>;
const categoryData = <?php echo json_encode($chart_data['sales_by_category']); ?>;

// === GRÁFICO DE VENDAS - LINHA DE MONTANHA/ONDA ===
const salesCtx = document.getElementById('salesChart').getContext('2d');
const gradient = salesCtx.createLinearGradient(0, 0, 0, 350);
gradient.addColorStop(0, 'rgba(59, 130, 246, 0.8)');
gradient.addColorStop(0.4, 'rgba(59, 130, 246, 0.4)');
gradient.addColorStop(1, 'rgba(59, 130, 246, 0.05)');

new Chart(salesCtx, {
    type: 'line',
    data: {
        labels: salesData.map(d => {
            const date = new Date(d.date);
            return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
        }),
        datasets: [{
            label: 'Vendas (R$)',
            data: salesData.map(d => parseFloat(d.total)),
            fill: true,
            borderColor: '#3b82f6',
            backgroundColor: gradient,
            borderWidth: 4,
            tension: 0.5,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: '#3b82f6',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointHoverBackgroundColor: '#2563eb',
            pointHoverBorderColor: '#fff',
            pointHoverBorderWidth: 3,
            showLine: true,
            spanGaps: true,
            cubicInterpolationMode: 'monotone',
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            intersect: false,
            mode: 'index',
        },
        plugins: {
            legend: { 
                display: true,
                labels: { color: '#94a3b8', font: { size: 14, weight: '600' } }
            },
            tooltip: {
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                titleColor: '#f1f5f9',
                bodyColor: '#94a3b8',
                borderColor: '#3b82f6',
                borderWidth: 2,
                padding: 14,
                displayColors: false,
                titleFont: { size: 14, weight: 'bold' },
                bodyFont: { size: 13 },
                callbacks: {
                    label: context => 'R$ ' + parseFloat(context.raw).toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2})
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: { 
                    color: 'rgba(59,130,246,0.1)',
                    drawBorder: false
                },
                ticks: { 
                    color: '#94a3b8',
                    font: { size: 12, weight: '500' },
                    callback: function(value) {
                        return 'R$ ' + value.toLocaleString('pt-BR');
                    }
                }
            },
            x: {
                grid: { display: false },
                ticks: { color: '#94a3b8', font: { size: 12, weight: '500' } }
            }
        }
    }
});

// === GRÁFICO DE CATEGORIAS (ROSCA) ===
const categoryCtx = document.getElementById('categoryChart').getContext('2d');
new Chart(categoryCtx, {
    type: 'doughnut',
    data: {
        labels: categoryData.map(d => d.category),
        datasets: [{
            data: categoryData.map(d => parseFloat(d.total)),
            backgroundColor: ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { color: '#94a3b8', padding: 15, font: { size: 12 } }
            },
            tooltip: {
                callbacks: {
                    label: context => context.label + ': R$ ' + parseFloat(context.raw).toFixed(2)
                }
            }
        }
    }
});
</script>

<?php
db_close($conn);
require_once 'inclusoes/rodape.php';
?>
