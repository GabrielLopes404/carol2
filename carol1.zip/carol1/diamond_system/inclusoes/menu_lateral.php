<div class="sidebar">
    <div class="sidebar-header">
        <a href="<?php echo BASE_URL; ?>painel.php" class="sidebar-brand">
            <div class="sidebar-brand-icon">
                <i class="fas fa-gem"></i>
            </div>
            <span class="sidebar-brand-text">Diamond System</span>
        </a>
    </div>
    
    <nav class="sidebar-nav">
        <div class="nav-section-title">Menu Principal</div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>painel.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'painel.php' ? 'active' : ''; ?>">
                <i class="fas fa-chart-line"></i>
                <span>Dashboard</span>
            </a>
        </div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>vitrine.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'vitrine.php' ? 'active' : ''; ?>">
                <i class="fas fa-store"></i>
                <span>Vitrine</span>
            </a>
        </div>
        
        <div class="nav-section-title">Vendas</div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>nova_venda.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'nova_venda.php' ? 'active' : ''; ?>">
                <i class="fas fa-cash-register"></i>
                <span>Nova Venda</span>
            </a>
        </div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>vendas.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'vendas.php' || basename($_SERVER['PHP_SELF']) == 'detalhes_venda.php' ? 'active' : ''; ?>">
                <i class="fas fa-shopping-cart"></i>
                <span>Vendas</span>
            </a>
        </div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>clientes.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'clientes.php' ? 'active' : ''; ?>">
                <i class="fas fa-users"></i>
                <span>Clientes</span>
            </a>
        </div>
        
        <?php if (can_manage_products()): ?>
        <div class="nav-section-title">Gestão</div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>produtos.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'produtos.php' ? 'active' : ''; ?>">
                <i class="fas fa-gem"></i>
                <span>Produtos</span>
            </a>
        </div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>categorias.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'categorias.php' ? 'active' : ''; ?>">
                <i class="fas fa-tags"></i>
                <span>Categorias</span>
            </a>
        </div>
        <?php else: ?>
        <div class="nav-section-title">Produtos</div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>produtos.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'produtos.php' ? 'active' : ''; ?>">
                <i class="fas fa-gem"></i>
                <span>Ver Produtos</span>
            </a>
        </div>
        <?php endif; ?>
        
        <?php if (is_admin() || is_manager()): ?>
        <div class="nav-section-title">Relatórios</div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>relatorios.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'relatorios.php' ? 'active' : ''; ?>">
                <i class="fas fa-chart-bar"></i>
                <span>Relatórios</span>
            </a>
        </div>
        <?php endif; ?>
        
        <?php if (is_admin() || is_manager()): ?>
        <div class="nav-section-title">Sistema</div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>usuarios.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'usuarios.php' ? 'active' : ''; ?>">
                <i class="fas fa-user-shield"></i>
                <span>Usuários</span>
            </a>
        </div>
        <?php endif; ?>
        
        <div class="nav-section-title">Conta</div>
        
        <div class="nav-item">
            <a href="<?php echo BASE_URL; ?>sair.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Sair</span>
            </a>
        </div>
    </nav>
</div>

<div class="main-content">
