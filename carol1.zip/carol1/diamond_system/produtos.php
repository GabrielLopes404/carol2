<?php
require_once 'configuracao/config.php';
require_once 'classes/Produto.php';

require_login();

$conn = db_connect();
$product = new Product($conn);

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && can_edit_products()) {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $category_id = $_POST['category_id'] ?? 0;
    $price = str_replace(',', '.', str_replace('.', '', $_POST['price'] ?? '0'));
    $cost = str_replace(',', '.', str_replace('.', '', $_POST['cost'] ?? '0'));
    $stock = $_POST['stock'] ?? 0;
    
    $image = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = upload_image($_FILES['image']);
    }
    
    if ($action == 'create') {
        if ($product->create($name, $description, $category_id, $price, $cost, $stock, $image)) {
            display_success('Produto cadastrado com sucesso!');
            redirect(BASE_URL . 'produtos.php');
        } else {
            display_error('Erro ao cadastrar produto.');
        }
    } elseif ($action == 'edit' && $id > 0) {
        if ($product->update($id, $name, $description, $category_id, $price, $cost, $stock, $image)) {
            display_success('Produto atualizado com sucesso!');
            redirect(BASE_URL . 'produtos.php');
        } else {
            display_error('Erro ao atualizar produto.');
        }
    }
}

if ($action == 'delete' && $id > 0) {
    if (!can_delete_products()) {
        display_error('Você não tem permissão para excluir produtos.');
        redirect(BASE_URL . 'produtos.php');
    }
    
    if ($product->delete($id)) {
        display_success('Produto excluído com sucesso!');
    } else {
        display_error('Erro ao excluir produto.');
    }
    redirect(BASE_URL . 'produtos.php');
}

$products = $product->getAll();
$categories = $product->getCategories();
$page_title = 'Produtos';

require_once 'inclusoes/cabecalho.php';
require_once 'inclusoes/menu_lateral.php';
?>

<?php if ($action == 'list'): ?>
<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-gem me-2"></i><?php echo can_edit_products() ? 'Gerenciar Produtos' : 'Visualizar Produtos'; ?></h1>
    <?php if (can_edit_products()): ?>
    <div class="btn-toolbar mb-2">
        <a href="?action=create" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> Novo Produto
        </a>
    </div>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Imagem</th>
                        <th>Nome</th>
                        <th>Categoria</th>
                        <th>Preço</th>
                        <th>Estoque</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $p): ?>
                    <tr>
                        <td>
                            <?php if ($p['image']): ?>
                                <img src="<?php echo BASE_URL; ?>recursos/envios/produtos/<?php echo htmlspecialchars($p['image']); ?>" class="product-image" alt="<?php echo htmlspecialchars($p['name']); ?>">
                            <?php else: ?>
                                <div class="product-image d-flex align-items-center justify-content-center" style="background: rgba(59, 130, 246, 0.1);">
                                    <i class="fas fa-gem"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($p['name']); ?></td>
                        <td><?php echo htmlspecialchars($p['category_name'] ?? 'Sem categoria'); ?></td>
                        <td><?php echo format_money($p['price']); ?></td>
                        <td>
                            <span class="badge <?php echo $p['stock'] <= 5 ? 'bg-warning' : 'bg-success'; ?>">
                                <?php echo $p['stock']; ?>
                            </span>
                        </td>
                        <td>
                            <?php if (can_edit_products()): ?>
                            <a href="?action=edit&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-primary" title="Editar">
                                <i class="fas fa-edit"></i>
                            </a>
                            <?php endif; ?>
                            <?php if (can_delete_products()): ?>
                            <a href="?action=delete&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Tem certeza que deseja excluir este produto?')" title="Excluir">
                                <i class="fas fa-trash"></i>
                            </a>
                            <?php else: ?>
                            <a href="?action=view&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-info" title="Visualizar">
                                <i class="fas fa-eye"></i>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php elseif ($action == 'create' && can_edit_products()): ?>
<?php
$current_product = null;
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Novo Produto</h1>
    <div class="btn-toolbar mb-2">
        <a href="produtos.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    </div>
</div>

<form method="post" enctype="multipart/form-data">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card mb-4">
                <div class="card-header">Informações do Produto</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nome do Produto</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Descrição</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="category_id" class="form-label">Categoria</label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="">Selecione...</option>
                                <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>">
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="image" class="form-label">Imagem</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="price" class="form-label">Preço de Venda</label>
                            <input type="text" class="form-control money-input" id="price" name="price" value="0,00" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="cost" class="form-label">Custo</label>
                            <input type="text" class="form-control money-input" id="cost" name="cost" value="0,00" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="stock" class="form-label">Estoque</label>
                            <input type="number" class="form-control" id="stock" name="stock" value="0" required min="0">
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save me-2"></i>Salvar Produto
                </button>
            </div>
        </div>
    </div>
</form>

<?php elseif ($action == 'edit' && can_edit_products()): ?>
<?php
$current_product = null;
if ($action == 'edit' && $id > 0) {
    $current_product = $product->getById($id);
    if (!$current_product) {
        display_error('Produto não encontrado.');
        redirect(BASE_URL . 'produtos.php');
    }
}
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo $action == 'create' ? 'Novo Produto' : 'Editar Produto'; ?></h1>
    <div class="btn-toolbar mb-2">
        <a href="produtos.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    </div>
</div>

<form method="post" enctype="multipart/form-data">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card mb-4">
                <div class="card-header">Informações do Produto</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nome do Produto</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($current_product['name'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Descrição</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($current_product['description'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="category_id" class="form-label">Categoria</label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="">Selecione...</option>
                                <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" <?php echo ($current_product['category_id'] ?? '') == $cat['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="image" class="form-label">Imagem</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="price" class="form-label">Preço de Venda</label>
                            <input type="text" class="form-control money-input" id="price" name="price" value="<?php echo number_format($current_product['price'] ?? 0, 2, ',', '.'); ?>" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="cost" class="form-label">Custo</label>
                            <input type="text" class="form-control money-input" id="cost" name="cost" value="<?php echo number_format($current_product['cost'] ?? 0, 2, ',', '.'); ?>" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="stock" class="form-label">Estoque</label>
                            <input type="number" class="form-control" id="stock" name="stock" value="<?php echo $current_product['stock'] ?? 0; ?>" required min="0">
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save me-2"></i>Salvar Produto
                </button>
            </div>
        </div>
    </div>
</form>

<?php elseif ($action == 'view' && $id > 0): ?>
<?php
$current_product = $product->getById($id);
if (!$current_product) {
    display_error('Produto não encontrado.');
    redirect(BASE_URL . 'produtos.php');
}
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Visualizar Produto</h1>
    <div class="btn-toolbar mb-2">
        <a href="produtos.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card mb-4">
            <div class="card-header">Informações do Produto</div>
            <div class="card-body">
                <?php if (!empty($current_product['image'])): ?>
                <div class="text-center mb-4">
                    <img src="<?php echo BASE_URL; ?>recursos/envios/produtos/<?php echo htmlspecialchars($current_product['image']); ?>" 
                         alt="<?php echo htmlspecialchars($current_product['name']); ?>" 
                         class="img-fluid rounded" 
                         style="max-height: 300px;">
                </div>
                <?php endif; ?>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Nome do Produto</label>
                    <p class="form-control-plaintext"><?php echo htmlspecialchars($current_product['name']); ?></p>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Descrição</label>
                    <p class="form-control-plaintext"><?php echo htmlspecialchars($current_product['description'] ?: 'Sem descrição'); ?></p>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Categoria</label>
                        <p class="form-control-plaintext"><?php echo htmlspecialchars($current_product['category_name'] ?? 'Sem categoria'); ?></p>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Estoque</label>
                        <p class="form-control-plaintext">
                            <span class="badge <?php echo $current_product['stock'] <= 5 ? 'bg-warning' : 'bg-success'; ?>" style="font-size: 14px;">
                                <?php echo $current_product['stock']; ?> unidades
                            </span>
                        </p>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Preço de Venda</label>
                        <p class="form-control-plaintext text-success fs-4 fw-bold"><?php echo format_money($current_product['price']); ?></p>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Custo</label>
                        <p class="form-control-plaintext"><?php echo format_money($current_product['cost']); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php endif; ?>

<?php
db_close($conn);
require_once 'inclusoes/rodape.php';
?>
